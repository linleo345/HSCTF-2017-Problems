Hello! This is an archive of HSCTF 4 in 2017! You start solving these
problems with your team, and on wednesday, more problems are released! 

Happy Solving! 
-Leo(archiver)




Notes*: Ping pong original documentation and ShadyJDawg's Website was not saved :(

======================================================
*th3 p0t83s not solved problems:

300-Digital Digits
300-Lost Keith
300-Max's Maximal Triangles
400-Grid
400-Magic Matrices
400-Never say goodbyte
500-Keith and Dawg 6
600-Ping Pong 600
(insert all wednesday problems here)

(MVP to p0t80 for most of the team's points)
============================================================
*reproduction of HSCTF's work is only used for educational purposes and is therefore legal.  All rights reserved.